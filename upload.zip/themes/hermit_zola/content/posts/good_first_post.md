+++
title="This is a good first post"
date=2019-08-23
draft=false
[taxonomies]
tags=["hello", "blog", "first"]
+++

So i went there and did all that but as you know:
* This point was important 
* This as well...
* And not to mention this one


So i did those other things but:
1. The first thing
2. And the second thing
3. But the third was the `best`

And then the guy said:
> Man, i'm not gonna be the part of the system

And showed me this:

<img src="https://dummyimage.com/640x4:3/">


I said factorial this...

```rust
fn factorial(n: u64) -> u64 {
    match n {
        0 => 1,
        _ => n * factorial(n-1)
    }
}
```

Then i shouted

# Hello

... and the echo answered:

## Hello

### Hello 

#### Hello 
[zola!!!][1]

[1]: https://www.getzola.org/
